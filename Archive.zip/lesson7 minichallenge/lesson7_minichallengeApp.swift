//
//  lesson7_minichallengeApp.swift
//  lesson7 minichallenge
//
//  Created by Alvarez Marco Lorenzo Tanzon on 21/8/23.
//

import SwiftUI

@main
struct lesson6_mini_challengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(newCheeseName: "Enter cheese name", newCheeseHoles: 0, newCheeseMilk: true, newCheeseType: "Cow")
        }
    }
}

